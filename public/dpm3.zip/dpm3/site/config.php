<?php
$ENGINE = "engine/";
$SITE = "site/";
$TASKLIST = "GLOBALS";
$dbConnect = 1;
$dbserver ="localhost" ;
$dbuser ="root";
$dbpass ="isiri";
$dbname ="dpm_maindb_new";
$logopath = "site/img/logo/";
$uploadpath = "site/upload/";
?>
