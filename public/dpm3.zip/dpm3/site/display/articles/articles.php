

<div id="">
	 <div class="logocell"><b>Journal of American Medicine</b></div>
	 <div class="desccell"><a href="" >Article 1</a><br/><a href="" >Article 2</a><br/><a href="" >Article 3</a><br/><a href="" >More</a><br/></div>
	 <div class="clear"></div>
	 <hr class="hr1" />
</div>

<div id="">
	 <div class="logocell"><b>American Medical Journal</b></div>
	 <div class="desccell"><a href="" >Article 1</a><br/><a href="" >Article 2</a><br/><a href="" >Article 3</a><br/><a href="" >More</a><br/></div>
	 <div class="clear"></div>
	 <hr class="hr1" />
</div>



<div id="">
	 <div class="logocell"><b>American Pediatrics</b></div>
	 <div class="desccell"><a href="" >Article 1</a><br/><a href="" >Article 2</a><br/><a href="" >Article 3</a><br/><a href="" >More</a><br/></div>
	 <div class="clear"></div>
	 <hr class="hr1" />
</div>