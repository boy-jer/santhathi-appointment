<?php

if ($USERLOGGED != 1)
{
echo <<<xx
<h2 class="">ATTENTION: You need to be an admin to access this.</h2>
xx;
}
else
{
?>
<!-- dts changes start -->

<form id="theForm" name="theForm" action="/dpm3/site/commit/pptsave.php" method="post" class="ajax_form brdr4 pad3" enctype="multipart/form-data" >

<label for="file">Filename:</label>
<input type="file" name="file" id="file" />
<br />
<input type="submit" name="submit" value="Submit" />
</form>
<?php
//echo makeButton( $type="BUTTON", $display="Save PPT", $id="", $func="checkit('');", $class="" );
}
?>

