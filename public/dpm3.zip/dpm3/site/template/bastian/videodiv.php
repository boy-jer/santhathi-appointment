<div id="videodiv" class="popupouter" style="display:none;">
<div id="videodivinner" class="popupinner  brdr2 ">
	 <div id="videodivtitlebar" class="ht1">
	 	  <h1 class="fl1 htitle" id="videodivtitle"></h1><!-- videodivtitle -->
	 	  <div class="fr1">
		  
<?php echo makeButton( $type="BUTTON", $display="Close", $id="", $func="toggleDiv('videodiv')", $class="" );?>
	  
		  </div>
	 	  <div class="clear"></div>
	 </div><!-- videodivtitlebar -->
	 <div id="videodivcontent">
	 
	 </div><!-- videodivcontent -->	 
</div><!-- videodivinner -->
</div><!-- videodiv -->