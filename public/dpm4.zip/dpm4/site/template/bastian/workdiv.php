<div id="workerdiv" class="popupouter" style="display:none;">
<div id="workerdivinner" class="popupinner  brdr2 ">
	 <div id="workerdivtitlebar" class="ht1">
	 	  <h1 class="fl1 htitle" id="workerdivtitle"></h1><!-- workerdivtitle -->
	 	  <div class="fr1">
		  
<?php echo makeButton( $type="BUTTON", $display="Close", $id="", $func="toggleDiv('workerdiv')", $class="" );?>
	  
		  </div>
	 	  <div class="clear"></div>
	 </div><!-- workerdivtitlebar -->
	 <div id="workerdivcontent">
	 <form name="deetForm"></form>
	 </div><!-- workerdivcontent -->	 
</div><!-- workerdivinner -->
</div><!-- workerdiv -->