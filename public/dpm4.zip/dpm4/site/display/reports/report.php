<?php

require "site/display/reports/report_user.php";

//require "site/display/reports/report_gp_specialty.php";


?>


<html>

<div align="center">

<p class="rptText"> Activity for Dr. Emily Johnson from Jan-Jul 2011 </p>

<img src="site/display/reports/report1.png" height="400 px"  width="800 px" align="middle" alt="report1">

</div>

<br/>
<hr>

<div align="center">

<p class="rptText"> Activity for Cardiologists from Jan-Jul 2011 </p>

<img src="site/display/reports/report3.png" height="400 px"  width="800 px" align="middle" alt="report1">

</div>

<br/>
<hr>

<div align="center">

<p class="rptText"> Activity for General Practitioners from Jan-Jul 2011 </p>

<img src="site/display/reports/report2.png" height="400 px"  width="800 px" align="middle" alt="report1">

</div>


</html>